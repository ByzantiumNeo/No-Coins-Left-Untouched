package gg.essential.loader.stage1;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.net.URI;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.jar.Attributes;
import java.util.jar.JarFile;
import net.minecraft.launchwrapper.ITweaker;
import net.minecraft.launchwrapper.Launch;
import net.minecraft.launchwrapper.LaunchClassLoader;
import net.minecraftforge.common.ForgeVersion;
import net.minecraftforge.fml.relauncher.CoreModManager;

public class EssentialSetupTweaker implements ITweaker {
  private final ITweaker stage0;
  
  private final EssentialLoader loader;
  
  public EssentialSetupTweaker(ITweaker stage0) throws Exception {
    this.stage0 = stage0;
    if (DelayedStage0Tweaker.isRequired()) {
      DelayedStage0Tweaker.prepare(stage0);
      this.loader = null;
      return;
    } 
    Forge forge = Forge.getIfPresent();
    Unknown unknown = new Unknown.Impl();
    Platform platform = (forge != null) ? forge : unknown;
    platform.setupPreLoad(this);
    this.loader = EssentialLoader.getInstance(platform.getVersion());
    this.loader.load(Launch.minecraftHome.toPath());
    platform.setupPostLoad(this);
  }
  
  public void acceptOptions(List<String> args, File gameDir, File assetsDir, String profile) {}
  
  public void injectIntoClassLoader(LaunchClassLoader classLoader) {
    if (this.loader == null) {
      DelayedStage0Tweaker.inject();
      return;
    } 
    this.loader.initialize();
  }
  
  public String getLaunchTarget() {
    return null;
  }
  
  public String[] getLaunchArguments() {
    return new String[0];
  }
  
  private static interface Platform {
    String getVersion();
    
    default void setupPreLoad(EssentialSetupTweaker stage1) throws Exception {}
    
    default void setupPostLoad(EssentialSetupTweaker stage1) throws Exception {}
  }
  
  private static interface Unknown extends Platform {
    public static class Impl implements Unknown {
      public String getVersion() {
        return "unknown";
      }
    }
  }
  
  public static class Impl implements Unknown {
    public String getVersion() {
      return "unknown";
    }
  }
  
  private static interface Forge extends Platform {
    static Forge getIfPresent() throws IOException {
      if (Launch.classLoader.getClassBytes("net.minecraftforge.common.ForgeVersion") != null)
        return getUnchecked(); 
      return null;
    }
    
    static Forge getUnchecked() {
      return new Impl();
    }
    
    public static class Impl implements Forge {
      private static final String MIXIN_TWEAKER = "org.spongepowered.asm.launch.MixinTweaker";
      
      public String getVersion() {
        try {
          return "forge_" + ForgeVersion.class.getDeclaredField("mcVersion").get((Object)null);
        } catch (IllegalAccessException|NoSuchFieldException e) {
          e.printStackTrace();
          return "unknown";
        } 
      }
      
      public void setupPostLoad(EssentialSetupTweaker stage1) throws Exception {
        List<SourceFile> sourceFiles = getSourceFiles(stage1.stage0.getClass());
        if (sourceFiles.isEmpty()) {
          System.out.println("Not able to determine current file. Mod will NOT work");
          return;
        } 
        for (SourceFile sourceFile : sourceFiles)
          setupSourceFile(sourceFile); 
      }
      
      private void setupSourceFile(SourceFile sourceFile) throws Exception {
        Field ignoredModFile = CoreModManager.class.getDeclaredField("ignoredModFiles");
        ignoredModFile.setAccessible(true);
        ((List)ignoredModFile.get((Object)null)).remove(sourceFile.file.getName());
        CoreModManager.getReparseableCoremods().add(sourceFile.file.getName());
        String coreMod = sourceFile.coreMod;
        if (coreMod != null && !sourceFile.mixin) {
          Method loadCoreMod = CoreModManager.class.getDeclaredMethod("loadCoreMod", new Class[] { LaunchClassLoader.class, String.class, File.class });
          loadCoreMod.setAccessible(true);
          ITweaker tweaker = (ITweaker)loadCoreMod.invoke((Object)null, new Object[] { Launch.classLoader, coreMod, sourceFile.file });
          ((List<ITweaker>)Launch.blackboard.get("Tweaks")).add(tweaker);
        } 
        if (sourceFile.mixin)
          try {
            Method addContainer;
            Object arg;
            injectMixinTweaker();
            Class<?> MixinBootstrap = Class.forName("org.spongepowered.asm.launch.MixinBootstrap");
            Class<?> MixinPlatformManager = Class.forName("org.spongepowered.asm.launch.platform.MixinPlatformManager");
            Object platformManager = MixinBootstrap.getDeclaredMethod("getPlatform", new Class[0]).invoke((Object)null, new Object[0]);
            try {
              addContainer = MixinPlatformManager.getDeclaredMethod("addContainer", new Class[] { URI.class });
              arg = sourceFile.file.toURI();
            } catch (NoSuchMethodException ignored) {
              Class<?> IContainerHandle = Class.forName("org.spongepowered.asm.launch.platform.container.IContainerHandle");
              Class<?> ContainerHandleURI = Class.forName("org.spongepowered.asm.launch.platform.container.ContainerHandleURI");
              addContainer = MixinPlatformManager.getDeclaredMethod("addContainer", new Class[] { IContainerHandle });
              arg = ContainerHandleURI.getDeclaredConstructor(new Class[] { URI.class }).newInstance(new Object[] { sourceFile.file.toURI() });
            } 
            addContainer.invoke(platformManager, new Object[] { arg });
          } catch (Exception e) {
            e.printStackTrace();
          }  
      }
      
      private List<SourceFile> getSourceFiles(Class<?> tweakerClass) {
        String tweakerClassName = tweakerClass.getName();
        List<SourceFile> sourceFiles = new ArrayList<>();
        for (URL url : Launch.classLoader.getSources()) {
          try {
            URI uri = url.toURI();
            if (!"file".equals(uri.getScheme()))
              continue; 
            File file = new File(uri);
            if (!file.exists() || !file.isFile())
              continue; 
            String tweakClass = null;
            String coreMod = null;
            boolean mixin = false;
            try (JarFile jar = new JarFile(file)) {
              if (jar.getManifest() != null) {
                Attributes attributes = jar.getManifest().getMainAttributes();
                tweakClass = attributes.getValue("TweakClass");
                coreMod = attributes.getValue("FMLCorePlugin");
                mixin = (attributes.getValue("MixinConfigs") != null);
              } 
            } 
            if (tweakerClassName.equals(tweakClass))
              sourceFiles.add(new SourceFile(file, coreMod, mixin)); 
          } catch (Exception e) {
            e.printStackTrace();
          } 
        } 
        return sourceFiles;
      }
      
      private void injectMixinTweaker() throws ClassNotFoundException, IllegalAccessException, InstantiationException {
        List<String> tweakClasses = (List<String>)Launch.blackboard.get("TweakClasses");
        if (tweakClasses.contains("org.spongepowered.asm.launch.MixinTweaker")) {
          initMixinTweaker();
          return;
        } 
        if (Launch.blackboard.get("mixin.initialised") != null)
          return; 
        System.out.println("Injecting MixinTweaker from EssentialSetupTweaker");
        List<ITweaker> tweaks = (List<ITweaker>)Launch.blackboard.get("Tweaks");
        tweaks.add(initMixinTweaker());
      }
      
      private ITweaker initMixinTweaker() throws ClassNotFoundException, IllegalAccessException, InstantiationException {
        Launch.classLoader.addClassLoaderExclusion("org.spongepowered.asm.launch.MixinTweaker".substring(0, "org.spongepowered.asm.launch.MixinTweaker".lastIndexOf('.')));
        return (ITweaker)Class.forName("org.spongepowered.asm.launch.MixinTweaker", true, (ClassLoader)Launch.classLoader).newInstance();
      }
      
      private static class SourceFile {
        final File file;
        
        final String coreMod;
        
        final boolean mixin;
        
        private SourceFile(File file, String coreMod, boolean mixin) {
          this.file = file;
          this.coreMod = coreMod;
          this.mixin = mixin;
        }
      }
    }
  }
}


/* Location:              D:\downloads\NotEnoughCoins-0.9.2.1-all (1).jar!\gg\essential\loader\stage0\stage1.jar!\gg\essential\loader\stage1\EssentialSetupTweaker.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */